<?php
$credentials = array(
  "server" => "localhost",
  "username" => "root",
  "pass" => "",
  "email"=> "",
  "dbName" => "users",
);
?>